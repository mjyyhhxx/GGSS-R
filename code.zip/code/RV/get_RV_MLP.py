
from attacked_model import target_model_256, VGG16, MLP_1, MLP_2, MLP_3, ResNet18
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import random

def cross_entropy_for_onehot(pred, target):
    return torch.mean(torch.sum(- target * F.log_softmax(pred, dim=-1), 1))

device_str = f"cuda:{3}" if torch.cuda.is_available() else 'cpu'
device = torch.device(device_str)

criterion = nn.CrossEntropyLoss()  #nn.CrossEntropyLoss()
RV = 0

images_emb = torch.load('./images_embs.pt').to(device)
label_emb = torch.load('./label_embs.pt').to(device)
images_num = len(images_emb)
gaussian_vector_num = 50
for j in range(gaussian_vector_num):
    model = MLP_3().to(device)
    model.eval()
    print(f'the vector: {j}')
    vector = torch.randn(202788806).to(device)#MLP3:202788806 MLP2:100811714 MLP1:100729730
    for i in range(images_num): 
        image_i = images_emb[i].unsqueeze(0)
        label_i = label_emb[i].unsqueeze(0)
        image_i.requires_grad_()
        output = model(image_i)
        loss = criterion(output, label_i)
        grad_vector = torch.autograd.grad(outputs=loss, inputs=model.parameters(), create_graph = True)
        grad_vector = torch.cat([grad_vector_i.view(-1) for grad_vector_i in grad_vector])
        grad_vector_len = (grad_vector.shape)[0]
        filename = str(j).zfill(5) + '.pt'
        dot = torch.dot(grad_vector, vector)
        gradient = torch.autograd.grad(outputs = dot, inputs=image_i)[0]
        norm = torch.norm(gradient, p=2)
        RV = RV + norm
    print(f'RV now is: {RV / ((j+1)* images_num)}')
RV = RV / (gaussian_vector_num * images_num)
print(f'RV of MLP_3 is : {RV}')

    
